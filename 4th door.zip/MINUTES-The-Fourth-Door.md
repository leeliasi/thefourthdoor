# MINUTES AND STANDING RECORD: THE FOURTH DOOR

*(Lee Liasi x Pete Taylor joint venture. Lives in the Marketing Board project knowledge base. This document supersedes MINUTES-Outgrow in full. Latest version supersedes all prior chat discussion.)*

---

## INSTRUCTIONS TO THE BOARD (read first in any new chat)

This is the official record of decisions. In any new conversation, treat everything under **Settled decisions** as closed: do not reopen it unless Lee explicitly asks. Pick up from **Open items**. When Lee says "minute this", produce an update block in this format.

**The venture was formerly called Outgrow. It is now The Fourth Door.** Any older minutes referring to Outgrow are stale and should be ignored.

**Working files do not carry between chats.** The website and guide live as files Lee holds locally. At the start of any build session, ask him to upload the current file, and confirm the build number in the footer before touching anything. Do not work from memory of a previous session's file.

---

## THE VENTURE

Consult-for-equity partnership. **Lee Liasi** (built and ran 150+ businesses inside one group to £250m turnover and £500m+ in value, 3,000+ people led, 65+ acquisitions integrated, 15 brands run at once, 80+ rebrands; solo brand Tenfold Partners, tenfoldpartners.co.uk) and **Pete Taylor** (CEO advisor to £1m to £30m founders, 100+ CEOs coached across 15 years in the UK and Dubai, former bricks-and-mortar CEO, founder of Heroic Man; petetaylor.co.uk, heroicman.com).

Together: take founder-led businesses to institutional readiness, paid in equity rather than fees. Deal flow originates through Pete's CEO days, coaching programmes and newsletter.

---

## SETTLED DECISIONS

### Identity and contact

- **Name: The Fourth Door.** Domain **thefourthdoor.co.uk**. Email **info@thefourthdoor.co.uk**.
- Phone currently **020 7946 0100**, which is an Ofcom drama-range placeholder. There is no reserved fictional range in 020 3, so any invented 0203 number would likely belong to a real business. Must be replaced before launch.
- Footer legal details are test data and must be replaced.

### Commercial terms, now public on the site

- **Equity: 10% to 15% initially, vesting over time, rising to a maximum of 25% against agreed milestones.** Founder stays majority owner and chief executive.
- **Capacity: a maximum of five businesses at any one time.** Stated as a number, not as "a small number".
- Both figures also appear on page 15 of the guide.

### Positioning and language

- **UK market only.** Adjusted EBITDA is the UK standard, not SDE, which is American. Where a US term differs it is flagged in orange in the guide glossary. A US multiple must never be compared with a UK one.
- **The two-markets thesis** is the central argument: businesses sell either in the owner-managed market (individual buyers, 2x to 4x) or the institutional market (trade and private equity, 4x to 10x). **Management depth, not size or profit, decides which one you are in.**
- The partnership is described as **one build, not two**. Lee leads the commercial build, Pete leads the founder build, and both work on both. **No copy may justify either partner's involvement in the other's domain.** State credentials flat; never explain why someone is entitled to be there.
- Standing line: *"We build the business and the founder at the same time, because neither one gets there without the other."*

### Editorial standards (Ogilvy's veto, now house rules)

- **Never a single figure where a range exists.** Always show the range and take the middle, never the flattering end. State on the page that this is what you have done.
- **No trade term used without a plain-English definition.** The guide carries a 31-term glossary on pages 4 and 5 for this reason.
- **Never tell the reader his business is worth less.** State that two numbers exist and that using the wrong one causes the mismatch.
- **When the point is arithmetic, set it as arithmetic.** Sums go in tables, never in prose.
- No exclamation marks. No em dashes. No urgency mechanics. Every number carries its unit.

---

## THE ASSETS AS BUILT

### The website (Build 9.6)

Sections in order: hero, the wall, the three doors, the two builders, the work, selection, **the Month Test**, **the calculator**, **the 20 checks**, structure, the record, apply.

- Navigation is six items, three carrying a dot. **Solid dot = free and on the page. Hollow ring = costs you an email.** The nav must stay on one row; links hide below 1181px.
- Both forms carry a **safety guard**: with no endpoint set they refuse loudly rather than silently discarding a lead.
- WhatsApp appears once as a button, beside Submit Application, outlined rather than filled.

### The guide: "The 20 Checks A Buyer Runs On Your Business"

Sixteen pages, PDF, sources published. Contents: two markets, the glossary in two parts, the ladder, the four checks, the six deal-killers, the gap worked through, the 18-month sequence, the 20-point check scored, the close, sources.

**The title must keep the buyer as the actor and the reader's business as the object.** "Buyer's Check" and "business buyer's checklist" both fail, because they read as a checklist *for* buyers.

### The calculator model, recorded so it is not lost

**Multiple = sector band, scaled by size, positioned by readiness score.**

Sector bands (adjusted EBITDA): Software and SaaS 7 to 13. Technology services 5.5 to 8. Healthcare and care 5 to 9. Manufacturing, distribution, transport and logistics 4.5 to 7. Professional services 4 to 6.5. Home and trade services, food and drink, marketing and creative 3.5 to 6. E-commerce and construction 3 to 5. Retail 2 to 4.

Size factor applied to the whole band: under £250k 0.60. £250k to £500k 0.72. £500k to £1m 0.82. £1m to £2m 0.92. £2m to £5m 1.00. Above £5m 1.08.

Readiness: 20 checks in four groups. **The five founder checks count double**, giving a weighted score out of 25. Position within the band is weighted score divided by 25. Output is always a range, plus the range at 20 out of 20, the gap in pounds, and the three unticked checks that would move fastest.

---

## OPEN ITEMS

**Blocking launch**

1. Form endpoint (MailerLite, ConvertKit or similar). Until set, no application or download request is captured.
2. Real company details for the footer: legal entity, company number, registered address.
3. Real telephone number.
4. Privacy notice page at /privacy.
5. Upload og-image.png to the domain root so shared links render.

**Needing Lee**

6. Sense-check the calculator bands against businesses he has actually bought. This is the one test only he can run.
7. The exact "Leaders Coached" figure from the tenfoldpartners.co.uk counter, to replace "Hundreds" on the Record row.
8. One before-and-after build for the proof section, anonymised by sector and size if necessary. **This remains the single biggest gap: there is still no voice on the site other than Lee's and Pete's own.**

**Needing Pete**

9. **Pete has not yet seen any of this.** His bio, his role label and the crossover line are all statements about him written without him present. Send before anything goes near a domain.
10. One evidenced performance number from Pete, to replace the only unevidenced claim in either bio ("measurable step-changes in performance").

**Still outstanding from earlier sessions**

11. UK trademark search on The Fourth Door before anything prints.
12. Domain purchases if not yet completed.
13. Decision on whether the hero should name the sale explicitly. Currently the transaction is implied by the wall and the doors and only stated plainly in the FAQ. Deliberate, but unresolved.

---

## WORKING RULES ESTABLISHED THIS SESSION

- **Build number in the footer.** Confirm it before reviewing anything. Four rounds were lost earlier in the project to reviewing a stale file.
- **One current file only.** Delete superseded versions from the output folder rather than leaving them alongside.
- **A change to the guide's cover requires the site's embedded cover image to be regenerated in the same pass**, or the site silently shows a stale picture with no error.
- **Render and measure before claiming a fix.** Every layout claim in this session was verified across multiple screen widths, and three of the fixes turned out to have causes different from the obvious one.

---

## SESSION LOG

**Session 4 (25 July 2026). Website and lead asset build.**

Site taken from Build 3.8 to 9.6. Guide created from scratch and rebuilt three times.

Faults found and fixed, none of which were cosmetic: the hero was cut off at every screen size tested because each headline phrase was wrapping into two lines; the navigation bar was silently wrapping onto two rows; the nav logo and first link were touching at exactly zero pixels; the application form's name, business and answer fields had no `name` attribute and would have transmitted nothing; the guide cover's decorative door was in the layout flow rather than behind it, eating 298px; the Record row carried a cell reading "0+"; nine navigation dots had no accessible labels.

Copy faults found by Lee acting as test reader, all of the same class (assumed knowledge): "data room", "a turn", "commission", "nothing invented", and a worked example whose numbers collided so the arithmetic could not be followed. Each was fixed at source, and the glossary exists because of them.

Two research corrections against Lee's challenge, both of which strengthened the argument: SDE is American and the UK works from adjusted EBITDA, which removed the confusing two-numbers problem entirely; and readiness alone cannot lift a small business to 7x to 9x, because size scales the whole band. The calculator returned 14.9x for a £750k SaaS business on first test and the model was rebuilt.

Ruled during the session: the guide is a published standard, not a lead magnet; the Month Test stays ungated; one asset, not a resource library; two entry points to the guide but one destination; the founder checks weigh double; ranges always, middle never flattering end.

---

*End of record. Next session: pick up from Open items. Confirm the build number in the footer of whatever file Lee uploads before making any change.*
